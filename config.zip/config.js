const CONFIG = {
  WS_URL: 'ws://localhost:8080'
};